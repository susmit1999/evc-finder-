import React, { Component } from 'react'
import { View, Text} from 'react-native';

export default class Register extends Component {
  render() {
    return(
      <View><Text>Register</Text></View>
    )
  }
}